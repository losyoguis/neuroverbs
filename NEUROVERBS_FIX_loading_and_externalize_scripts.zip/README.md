# NeuroVerbs

Actualización v4 (DEFINITIVA):
- Voz pasiva SIN traducción al español en READING (forzado a nivel de render)
- Voz pasiva SIN español en tablas
- Voz activa conserva EN/ES
