// Cliente sencillo para consumir la API (Worker o Proxy PHP)
(function(){
  const cfg = () => (window.NEUROVERBS_API || {base:"", endpoints:{}});

  function withTimeout(promise, ms){
    return new Promise((resolve, reject)=>{
      const t = setTimeout(()=>reject(new Error("Tiempo de espera agotado")), ms);
      promise.then(v=>{clearTimeout(t); resolve(v);}).catch(e=>{clearTimeout(t); reject(e);});
    });
  }

  async function postJson(path, data){
    const url = cfg().base + path;
    const res = await withTimeout(fetch(url, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data || {})
    }), 45000);

    const text = await res.text();
    let json;
    try { json = text ? JSON.parse(text) : {}; } catch(e){ json = {error:"Respuesta no es JSON", raw:text}; }

    if(!res.ok){
      const msg = (json && (json.error || json.message)) ? (json.error || json.message) : ("HTTP " + res.status);
      const err = new Error(msg);
      err.status = res.status;
      err.payload = json;
      throw err;
    }
    return json;
  }

  function mapLevel(levelKey){
    // Front usa: easy / medium / hard
    // Worker usa (recomendado): facil / medio / dificil
    const m = { easy: "facil", medium: "medio", hard: "dificil" };
    return m[levelKey] || levelKey || "medio";
  }

  window.IA = {
    async generate({topic, levelKey, level, lang}){
      const lvl = mapLevel(levelKey || level);
      return await postJson(cfg().endpoints.generate, { topic, level: lvl, lang: lang || "en" });
    },
    async vocab({term, context}){
      return await postJson(cfg().endpoints.vocab, { term, context: context || "" });
    },
    async chat({mode, messages, levelKey, level}){
      // Requiere endpoint /chat en el Worker
      const lvl = mapLevel(levelKey || level);
      return await postJson(cfg().endpoints.chat, { mode: mode || "writing", level: lvl, messages: messages || [] });
    }
  };
})();
